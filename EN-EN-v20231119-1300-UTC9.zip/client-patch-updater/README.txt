[ v1.0 ]

Feature:
- Auto-downloading newest translated PAK file.

Based on:
https://github.com/DOTzX/BP-ClientPatch-Updater/releases

Files required:
- DotNetZip.dll
- Newtonsoft.Json.dll
