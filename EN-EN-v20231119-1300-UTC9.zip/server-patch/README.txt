[ v1.4 ]

Feature:
- Translation
- Auto-updating/downloading newest translated loc.json file
- Fixed "Translation sent" but in the game didn't translated

Based on:
https://github.com/DOTzX/BP-translate/releases

Files required:
- DotNetZip.dll
- Newtonsoft.Json.dll
- loc.json (it will auto-downloaded)
- bpmasterdata.pfx

========

[ v1.1 ]

Feature:
- Translation

Based on:
https://github.com/ArtFect/BP-translate/releases

Files required:
- loc.json
- bpmasterdata.pfx